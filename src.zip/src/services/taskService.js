// src/services/taskService.js
import API from "./api";

// ✅ Get all tasks
export const getAllTasks = () => API.get("/api/tasks");

// ✅ Add a new task
export const addTask = (data) => API.post("/api/tasks", data);

// ✅ Update an existing task
export const updateTask = (id, data) => API.put(`/api/tasks/${id}`, data);

// ✅ Delete a task
export const deleteTask = (id) => API.delete(`/api/tasks/${id}`);
