// src/services/leadService.js
import API from "./api";

// ✅ All requests automatically include JWT from api.js
export const getAllLeads = () => API.get("/api/leads");
export const addLead = (data) => API.post("/api/leads", data);
export const updateLead = (id, data) => API.put(`/api/leads/${id}`, data);
export const deleteLead = (id) => API.delete(`/api/leads/${id}`);
