// src/services/api.js
import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8080", // ⚡ Keep only the host, do NOT add /api here
  headers: {
    "Content-Type": "application/json",
  },
});

// ✅ Automatically attach JWT token to every request
API.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ✅ Automatically handle 401 (Unauthorized) errors — optional
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn("Unauthorized - Redirecting to login...");
      localStorage.removeItem("token");
      window.location.href = "/login"; // redirect to login page
    }
    return Promise.reject(error);
  }
);

export default API;
