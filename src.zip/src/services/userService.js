// src/services/userService.js
import axiosInstance from "./axiosInstance";

export const getUsers = () => axiosInstance.get("/users");
