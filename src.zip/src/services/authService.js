// src/services/AuthService.js
import API from "./api";

// ✅ Register new user
export const register = (data) => API.post("/api/register", data);

// ✅ Login user (returns JWT)
export const login = async (data) => {
  try {
    const response = await API.post("/api/login", data);

    // Save token in localStorage
    if (response.data && response.data.token) {
      localStorage.setItem("token", response.data.token);
    }

    return response;
  } catch (error) {
    console.error("Login failed:", error.response?.data || error.message);
    throw error;
  }
};

// ✅ Get logged-in user's profile
export const getProfile = () => API.get("/api/users/me");
