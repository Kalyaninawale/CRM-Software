// src/services/customerService.js
import axios from "axios";

// Base API URL for customers
const API_URL = "http://localhost:8080/api/customers";

// Get token from localStorage
const getToken = () => localStorage.getItem("token");

// Fetch all customers
export const getCustomers = () => {
  return axios.get(API_URL, {
    headers: { Authorization: `Bearer ${getToken()}` },
  });
};

// Add a new customer
export const addCustomer = (customer) => {
  return axios.post(API_URL, customer, {
    headers: { Authorization: `Bearer ${getToken()}` },
  });
};

// Update a customer by ID
export const updateCustomer = (id, customer) => {
  return axios.put(`${API_URL}/${id}`, customer, {
    headers: { Authorization: `Bearer ${getToken()}` },
  });
};

// Delete a customer by ID
export const deleteCustomer = (id) => {
  return axios.delete(`${API_URL}/${id}`, {
    headers: { Authorization: `Bearer ${getToken()}` },
  });
};
