// src/services/salesService.js
import axios from "axios";

const API_URL = "http://localhost:8080/api/sales";

export const getSales = async () => {
  const token = localStorage.getItem("token");
  return await axios.get(API_URL, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

export const addSale = async (sale) => {
  const token = localStorage.getItem("token");
  return await axios.post(API_URL, sale, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

export const updateSale = async (id, sale) => {
  const token = localStorage.getItem("token");
  return await axios.put(`${API_URL}/${id}`, sale, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

export const deleteSale = async (id) => {
  const token = localStorage.getItem("token");
  return await axios.delete(`${API_URL}/${id}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
};
