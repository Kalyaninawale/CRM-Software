import React, { useEffect, useState } from "react";
import { getSales, addSale, updateSale, deleteSale } from "../services/salesService";
import { getCustomers } from "../services/customerService";
import axios from "axios";

export default function Sales() {
  const [sales, setSales] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null); // only current user
  const [formData, setFormData] = useState({
    customerId: "",
    assignedSalesRepId: "",
    amount: "",
    status: "Proposal",
    date: "",
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchSales();
    fetchCustomers();
    fetchCurrentUser();
  }, []);

  const fetchSales = async () => {
    try {
      const response = await getSales();
      setSales(response.data);
    } catch (error) {
      console.error("Error fetching sales:", error);
    }
  };

  const fetchCustomers = async () => {
    try {
      const response = await getCustomers();
      setCustomers(response.data);
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };

  const fetchCurrentUser = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get("http://localhost:8080/api/users/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCurrentUser(response.data);
      setFormData((prev) => ({ ...prev, assignedSalesRepId: response.data.id }));
    } catch (error) {
      console.error("Error fetching current user:", error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        customer: { id: formData.customerId },
        assignedSalesRep: { id: formData.assignedSalesRepId },
        amount: parseFloat(formData.amount),
        status: formData.status,
        date: formData.date,
      };

      if (editId) {
        await updateSale(editId, payload);
        setEditId(null);
      } else {
        await addSale(payload);
      }

      setFormData({
        customerId: "",
        assignedSalesRepId: currentUser?.id || "",
        amount: "",
        status: "Proposal",
        date: "",
      });

      fetchSales();
    } catch (error) {
      console.error("Error saving sale:", error);
    }
  };

  const handleEdit = (sale) => {
    setEditId(sale.id);
    setFormData({
      customerId: sale.customer.id,
      assignedSalesRepId: sale.assignedSalesRep.id,
      amount: sale.amount,
      status: sale.status,
      date: sale.date,
    });
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this sale?")) {
      try {
        await deleteSale(id);
        fetchSales();
      } catch (error) {
        console.error("Error deleting sale:", error);
      }
    }
  };

  return (
    <div className="container mx-auto p-4">
      {/* Embedded CSS */}
      <style>{`
        .container {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background-color: #f8f9fa;
          border-radius: 10px;
          box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h2 {
          text-align: center;
          margin-bottom: 20px;
          color: #333;
        }
        form label {
          display: block;
          margin-bottom: 5px;
          font-weight: 500;
          color: #555;
        }
        form input, form select {
          width: 100%;
          padding: 8px 10px;
          margin-bottom: 10px;
          border-radius: 5px;
          border: 1px solid #ccc;
        }
        form button {
          background-color: #007bff;
          color: #fff;
          padding: 8px 15px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          transition: 0.2s;
        }
        form button:hover {
          background-color: #0056b3;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        table, th, td {
          border: 1px solid #ccc;
        }
        th, td {
          padding: 10px;
          text-align: left;
        }
        th {
          background-color: #007bff;
          color: #fff;
        }
        tr:nth-child(even) {
          background-color: #f2f2f2;
        }
        .space-x-2 > * + * {
          margin-left: 5px;
        }
        button.bg-yellow-500 {
          background-color: #ffc107;
        }
        button.bg-yellow-500:hover {
          background-color: #e0a800;
        }
        button.bg-red-500 {
          background-color: #dc3545;
        }
        button.bg-red-500:hover {
          background-color: #c82333;
        }
        input[disabled] {
          background-color: #e9ecef;
        }
      `}</style>

      <h2 className="text-2xl font-bold mb-4">Sales Page</h2>

      {/* Add/Edit Sale Form */}
      <form onSubmit={handleSubmit} className="mb-6 space-y-4">
        <div>
          <label>Customer:</label>
          <select
            name="customerId"
            value={formData.customerId}
            onChange={handleChange}
            required
          >
            <option value="">Select Customer</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label>Sales Rep:</label>
          <input
            type="text"
            value={currentUser?.name || ""}
            disabled
            className="bg-gray-200 p-1 rounded"
          />
        </div>

        <div>
          <label>Amount:</label>
          <input
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Status:</label>
          <select name="status" value={formData.status} onChange={handleChange}>
            <option value="PROPOSAL">PROPOSAL</option>
            <option value="NEGOTIATION">NEGOTIATION</option>
            <option value="CLOSED-WON">CLOSED-WON</option>
            <option value="CLOSED-LOST">CLOSED-LOST</option>
          </select>
        </div>

        <div>
          <label>Date:</label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit">
          {editId ? "Update Sale" : "Add Sale"}
        </button>
      </form>

      {/* Sales List */}
      <table className="w-full border">
        <thead>
          <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Sales Rep</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {sales.map((sale) => (
            <tr key={sale.id}>
              <td>{sale.id}</td>
              <td>{sale.customer.name}</td>
              <td>{sale.assignedSalesRep.name}</td>
              <td>{sale.amount}</td>
              <td>{sale.status}</td>
              <td>{sale.date}</td>
              <td className="space-x-2">
                <button
                  className="bg-yellow-500 text-white px-2 py-1 rounded"
                  onClick={() => handleEdit(sale)}
                >
                  Edit
                </button>
                <button
                  className="bg-red-500 text-white px-2 py-1 rounded"
                  onClick={() => handleDelete(sale.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
