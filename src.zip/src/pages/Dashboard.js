import React from "react";
import { Link } from "react-router-dom";



export default function Dashboard() {
   
  return (
    <div className="container mt-5">
      <h2 className="mb-4">CRM Dashboard</h2>
      <ul className="list-group">
        <li className="list-group-item">
          <Link to="/customers">Manage Customers</Link>
        </li>
        <li className="list-group-item">
          <Link to="/leads">Manage Leads</Link>
        </li>
        <li className="list-group-item">
          <Link to="/tasks">Manage Tasks</Link>
        </li>
        <li className="list-group-item">
          <Link to="/sales">Manage Sales</Link>
        </li>
      </ul>
    </div>
  );
}
