import React, { useEffect, useState } from "react";
import { getCustomers, addCustomer, updateCustomer, deleteCustomer } from "../services/customerService";

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    address: "",
    notes: ""
  });

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const response = await getCustomers();
      setCustomers(response.data);
    } catch (err) {
      console.error("Error loading customers:", err);
    }
  };

  const handleChange = (e) => {
    setNewCustomer({ ...newCustomer, [e.target.name]: e.target.value });
  };

  const handleAdd = async () => {
    try {
      await addCustomer(newCustomer);
      setNewCustomer({
        name: "",
        email: "",
        phone: "",
        company: "",
        address: "",
        notes: ""
      });
      loadCustomers();
    } catch (err) {
      console.error("Error adding customer:", err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteCustomer(id);
      loadCustomers();
    } catch (err) {
      console.error("Error deleting customer:", err);
    }
  };

  return (
    <div className="container mt-4">
      {/* Embedded CSS */}
      <style>{`
        .container {
          max-width: 700px;
          margin: 50px auto;
          padding: 20px;
          background-color: #f8f9fa;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
          text-align: center;
          margin-bottom: 20px;
          color: #333;
        }
        .card {
          background-color: #fff;
          border: 1px solid #ddd;
          border-radius: 8px;
          padding: 20px;
          margin-bottom: 30px;
          box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .card h5 {
          margin-bottom: 15px;
          color: #555;
        }
        .form-control {
          border-radius: 5px;
          padding: 10px;
          margin-bottom: 10px;
        }
        textarea.form-control {
          resize: vertical;
          min-height: 60px;
        }
        .btn-primary {
          width: 100%;
          background-color: #007bff;
          border: none;
        }
        .btn-primary:hover {
          background-color: #0056b3;
        }
        .list-group {
          list-style-type: none;
          padding: 0;
          margin: 0;
        }
        .list-group-item {
          padding: 15px 20px;
          margin-bottom: 10px;
          border: 1px solid #ccc;
          border-radius: 8px;
          background-color: #fff;
          transition: all 0.2s ease;
        }
        .list-group-item:hover {
          background-color: #e9ecef;
        }
        .list-group-item button {
          min-width: 70px;
        }
      `}</style>

      <h2>Customer Management</h2>

      {/* Add Customer Form */}
      <div className="card p-3 mb-4" style={{ maxWidth: "600px" }}>
        <h5>Add New Customer</h5>
        <input className="form-control mb-2" name="name" placeholder="Name" value={newCustomer.name} onChange={handleChange} />
        <input className="form-control mb-2" name="email" placeholder="Email" value={newCustomer.email} onChange={handleChange} />
        <input className="form-control mb-2" name="phone" placeholder="Phone" value={newCustomer.phone} onChange={handleChange} />
        <input className="form-control mb-2" name="company" placeholder="Company" value={newCustomer.company} onChange={handleChange} />
        <input className="form-control mb-2" name="address" placeholder="Address" value={newCustomer.address} onChange={handleChange} />
        <textarea className="form-control mb-2" name="notes" placeholder="Notes" value={newCustomer.notes} onChange={handleChange} />
        <button className="btn btn-primary" onClick={handleAdd}>Add Customer</button>
      </div>

      {/* Customer List */}
      <ul className="list-group">
        {customers.map((c) => (
          <li key={c.id} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong>{c.name}</strong> — {c.email} | {c.phone}<br />
              <small>
                <b>Company:</b> {c.company} | <b>Address:</b> {c.address}<br />
                <b>Notes:</b> {c.notes}
              </small>
            </div>
            <button className="btn btn-danger btn-sm" onClick={() => handleDelete(c.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
