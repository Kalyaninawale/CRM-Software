import React, { useState, useEffect } from "react";
import { getAllTasks, addTask, deleteTask } from "../services/taskService";

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    dueDate: "",
    priority: "Low",
  });

  const priorityOptions = ["Low", "Medium", "High"];

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const res = await getAllTasks();
      setTasks(res.data);
    } catch (err) {
      console.error("Error loading tasks:", err.response?.data || err.message);
      alert("Failed to load tasks. Make sure you are logged in.");
    }
  };

  const handleChange = (e) => {
    setNewTask({ ...newTask, [e.target.name]: e.target.value });
  };

  const handleAdd = async () => {
    if (!newTask.title.trim() || !newTask.dueDate || !newTask.priority) {
      alert("Please fill Title, Due Date, and Priority.");
      return;
    }
    try {
      await addTask(newTask);
      setNewTask({ title: "", description: "", dueDate: "", priority: "Low" });
      loadTasks();
    } catch (err) {
      console.error("Error adding task:", err.response?.data || err.message);
      alert("Failed to add task. Make sure you are logged in.");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this task?")) return;
    try {
      await deleteTask(id);
      loadTasks();
    } catch (err) {
      console.error("Error deleting task:", err.response?.data || err.message);
      alert("Failed to delete task. Make sure you are logged in.");
    }
  };

  return (
    <div className="container mt-4">
      {/* Embedded CSS */}
      <style>{`
        .container {
          max-width: 700px;
          margin: 50px auto;
          padding: 20px;
          background-color: #f8f9fa;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
          text-align: center;
          margin-bottom: 20px;
          color: #333;
        }
        .card {
          background-color: #fff;
          border: 1px solid #ddd;
          border-radius: 8px;
          padding: 20px;
          margin-bottom: 30px;
          box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .card h5 {
          margin-bottom: 15px;
          color: #555;
        }
        .form-control, .form-select {
          border-radius: 5px;
          padding: 10px;
          margin-bottom: 10px;
        }
        .btn-primary {
          width: 100%;
          background-color: #007bff;
          border: none;
        }
        .btn-primary:hover {
          background-color: #0056b3;
        }
        .list-group {
          list-style-type: none;
          padding: 0;
          margin: 0;
        }
        .list-group-item {
          padding: 15px 20px;
          margin-bottom: 10px;
          border: 1px solid #ccc;
          border-radius: 8px;
          background-color: #fff;
          transition: all 0.2s ease;
        }
        .list-group-item:hover {
          background-color: #e9ecef;
        }
        .list-group-item button {
          min-width: 70px;
        }
        .text-muted {
          color: #6c757d;
        }
      `}</style>

      <h2 className="mb-4">Task Management</h2>

      {/* Add Task Form */}
      <div className="card p-3 mb-4" style={{ maxWidth: "600px" }}>
        <h5 className="mb-3">Add New Task</h5>
        <input
          className="form-control mb-2"
          name="title"
          placeholder="Task Title"
          value={newTask.title}
          onChange={handleChange}
        />
        <textarea
          className="form-control mb-2"
          name="description"
          placeholder="Description"
          value={newTask.description}
          onChange={handleChange}
        />
        <input
          type="date"
          className="form-control mb-2"
          name="dueDate"
          value={newTask.dueDate}
          onChange={handleChange}
        />
        <select
          className="form-select mb-3"
          name="priority"
          value={newTask.priority}
          onChange={handleChange}
        >
          {priorityOptions.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        <button className="btn btn-primary w-100" onClick={handleAdd}>
          Add Task
        </button>
      </div>

      {/* Task List */}
      <ul className="list-group">
        {tasks.length === 0 ? (
          <li className="list-group-item text-center text-muted">No tasks available.</li>
        ) : (
          tasks.map((task) => (
            <li key={task.id} className="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <strong>{task.title}</strong> — {task.description || "No description"}
                <br />
                <small>
                  <b>Due:</b> {task.dueDate} | <b>Priority:</b> {task.priority}
                </small>
              </div>
              <button className="btn btn-danger btn-sm" onClick={() => handleDelete(task.id)}>Delete</button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
