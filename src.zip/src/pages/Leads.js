import React, { useEffect, useState } from "react";
import { getAllLeads, addLead, deleteLead } from "../services/leadService";

export default function Leads() {
  const [leads, setLeads] = useState([]);
  const [newLead, setNewLead] = useState({
    name: "",
    contactInfo: "",
    source: "",
    status: "",
  });

  const sourceOptions = ["Web", "Ads", "Referral"];
  const statusOptions = ["New", "Contacted", "Qualified", "Converted", "Lost"];

  useEffect(() => {
    loadLeads();
  }, []);

  const loadLeads = async () => {
    try {
      const res = await getAllLeads();
      setLeads(res.data);
    } catch (err) {
      console.error("Error loading leads:", err.response?.data || err.message);
      alert("Failed to load leads. Please make sure you are logged in.");
    }
  };

  const handleChange = (e) => {
    setNewLead({ ...newLead, [e.target.name]: e.target.value });
  };

  const handleAdd = async () => {
    if (!newLead.name.trim() || !newLead.contactInfo.trim() || !newLead.source || !newLead.status) {
      alert("Please fill all fields including Source and Status.");
      return;
    }

    try {
      await addLead(newLead);
      setNewLead({ name: "", contactInfo: "", source: "", status: "" });
      loadLeads();
    } catch (err) {
      console.error("Error adding lead:", err.response?.data || err.message);
      alert("Failed to add lead. Make sure you are logged in.");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this lead?")) return;
    try {
      await deleteLead(id);
      loadLeads();
    } catch (err) {
      console.error("Error deleting lead:", err.response?.data || err.message);
      alert("Failed to delete lead. Make sure you are logged in.");
    }
  };

  return (
    <div className="container mt-4">
      {/* Embedded CSS */}
      <style>{`
        .container {
          max-width: 700px;
          margin: 50px auto;
          padding: 20px;
          background-color: #f8f9fa;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
          text-align: center;
          margin-bottom: 20px;
          color: #333;
        }
        .card {
          background-color: #fff;
          border: 1px solid #ddd;
          border-radius: 8px;
          padding: 20px;
          margin-bottom: 30px;
          box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .card h5 {
          margin-bottom: 15px;
          color: #555;
        }
        .form-control, .form-select {
          border-radius: 5px;
          padding: 10px;
          margin-bottom: 10px;
        }
        .btn-primary {
          width: 100%;
          background-color: #007bff;
          border: none;
        }
        .btn-primary:hover {
          background-color: #0056b3;
        }
        .list-group {
          list-style-type: none;
          padding: 0;
          margin: 0;
        }
        .list-group-item {
          padding: 15px 20px;
          margin-bottom: 10px;
          border: 1px solid #ccc;
          border-radius: 8px;
          background-color: #fff;
          transition: all 0.2s ease;
        }
        .list-group-item:hover {
          background-color: #e9ecef;
        }
        .list-group-item button {
          min-width: 70px;
        }
        .text-muted {
          color: #6c757d;
        }
      `}</style>

      <h2 className="mb-4">Lead Management</h2>

      {/* Add Lead Form */}
      <div className="card p-3 mb-4" style={{ maxWidth: "600px" }}>
        <h5 className="mb-3">Add New Lead</h5>
        <input
          className="form-control mb-2"
          name="name"
          placeholder="Lead Name"
          value={newLead.name}
          onChange={handleChange}
        />
        <input
          className="form-control mb-2"
          name="contactInfo"
          placeholder="Contact Info (Email / Phone)"
          value={newLead.contactInfo}
          onChange={handleChange}
        />
        <select
          className="form-select mb-2"
          name="source"
          value={newLead.source}
          onChange={handleChange}
        >
          <option value="">Select Source</option>
          {sourceOptions.map((src) => (
            <option key={src} value={src}>{src}</option>
          ))}
        </select>
        <select
          className="form-select mb-3"
          name="status"
          value={newLead.status}
          onChange={handleChange}
        >
          <option value="">Select Status</option>
          {statusOptions.map((status) => (
            <option key={status} value={status}>{status}</option>
          ))}
        </select>
        <button className="btn btn-primary w-100" onClick={handleAdd}>
          Add Lead
        </button>
      </div>

      {/* Leads List */}
      <ul className="list-group">
        {leads.length === 0 ? (
          <li className="list-group-item text-center text-muted">No leads available.</li>
        ) : (
          leads.map((lead) => (
            <li key={lead.id} className="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <strong>{lead.name}</strong> — {lead.contactInfo}
                <br />
                <small>
                  <b>Source:</b> {lead.source || "N/A"} | <b>Status:</b> {lead.status || "N/A"}
                </small>
              </div>
              <button className="btn btn-danger btn-sm" onClick={() => handleDelete(lead.id)}>Delete</button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
