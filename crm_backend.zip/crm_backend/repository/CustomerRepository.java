package com.crm.crm_backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crm.crm_backend.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> 
{
	
}
