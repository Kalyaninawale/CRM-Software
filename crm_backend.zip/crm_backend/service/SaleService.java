package com.crm.crm_backend.service;

import com.crm.crm_backend.model.*;
import com.crm.crm_backend.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SaleService {

    @Autowired
    private SaleRepository saleRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    public Sale createSale(Sale sale) {

        // ✅ Check customer exists
        Customer customer = customerRepository.findById(sale.getCustomer().getId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // ✅ Check assigned sales rep exists
        User rep = userRepository.findById(sale.getAssignedSalesRep().getId())
                .orElseThrow(() -> new RuntimeException("Assigned Sales Rep not found"));

        sale.setCustomer(customer);
        sale.setAssignedSalesRep(rep);

        return saleRepository.save(sale);
    }

    public List<Sale> getAllSales() {
        return saleRepository.findAll();
    }

    public Sale getSaleById(Long id) {
        return saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found"));
    }

    public Sale updateSale(Long id, Sale updatedSale) {
        Sale sale = getSaleById(id);

        sale.setAmount(updatedSale.getAmount());
        sale.setStatus(updatedSale.getStatus());
        sale.setDate(updatedSale.getDate());

        return saleRepository.save(sale);
    }

    public void deleteSale(Long id) {
        saleRepository.deleteById(id);
    }
}
