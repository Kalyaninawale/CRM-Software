package com.crm.crm_backend.service;

import com.crm.crm_backend.dto.TaskDTO;
import com.crm.crm_backend.model.Task;
import com.crm.crm_backend.model.User;
import com.crm.crm_backend.repository.TaskRepository;
import com.crm.crm_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserRepository userRepository;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    // ✅ Create task
    public Task createTask(Task task) {
        if (task.getAssignedTo() != null && task.getAssignedTo().getId() != null) {
            User user = userRepository.findById(task.getAssignedTo().getId()).orElse(null);
            task.setAssignedTo(user);
        } else {
            task.setAssignedTo(null);
        }
        return taskRepository.save(task);
    }

    // ✅ Get all tasks
    public List<TaskDTO> getAllTasks() {
        return taskRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ✅ Get single task
    public Task getTaskById(Long id) {
        return taskRepository.findById(id).orElse(null);
    }

    // ✅ Update task
    public Task updateTask(Long id, Task taskDetails) {
        Task task = taskRepository.findById(id).orElse(null);
        if (task == null) return null;

        task.setTitle(taskDetails.getTitle());
        task.setDescription(taskDetails.getDescription());
        task.setPriority(taskDetails.getPriority());
        task.setStatus(taskDetails.getStatus());
        task.setDueDate(taskDetails.getDueDate());

        if (taskDetails.getAssignedTo() != null && taskDetails.getAssignedTo().getId() != null) {
            User user = userRepository.findById(taskDetails.getAssignedTo().getId()).orElse(null);
            task.setAssignedTo(user);
        }

        return taskRepository.save(task);
    }

    // ✅ Delete task
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    // ✅ Convert Task → DTO
    public TaskDTO convertToDTO(Task task) {
        String assignedToName = (task.getAssignedTo() != null)
                ? task.getAssignedTo().getFullName()
                : "Unassigned";

        String dueDateStr = (task.getDueDate() != null)
                ? dateFormat.format(task.getDueDate())
                : null;

        return new TaskDTO(
                task.getId(),
                task.getTitle(),
                task.getDescription(),
                task.getPriority(),
                task.getStatus(),
                assignedToName,
                dueDateStr
        );
    }
}
