package com.crm.crm_backend.service;

import com.crm.crm_backend.dto.LeadDTO;
import com.crm.crm_backend.model.Lead;
import com.crm.crm_backend.model.User;
import com.crm.crm_backend.repository.LeadRepository;
import com.crm.crm_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeadService {

    @Autowired
    private LeadRepository leadRepository;

    @Autowired
    private UserRepository userRepository;

    // ✅ Create lead (link assignedSalesRep properly)
    public Lead createLead(Lead lead) {
        if (lead.getAssignedSalesRep() != null && lead.getAssignedSalesRep().getId() != null) {
            User salesRep = userRepository.findById(lead.getAssignedSalesRep().getId()).orElse(null);
            lead.setAssignedSalesRep(salesRep);
        } else {
            lead.setAssignedSalesRep(null);
        }

        return leadRepository.save(lead);
    }

    public List<LeadDTO> getAllLeads() {
        return leadRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public LeadDTO convertToDTO(Lead lead) {
        String salesRepName = (lead.getAssignedSalesRep() != null)
                ? lead.getAssignedSalesRep().getFullName()
                : "Unassigned";

        return new LeadDTO(
                lead.getId(),
                lead.getName(),
                lead.getContactInfo(),
                lead.getSource(),
                lead.getStatus(),
                salesRepName
        );
    }

    public Lead getLeadById(Long id) {
        return leadRepository.findById(id).orElse(null);
    }

    public Lead updateLead(Long id, Lead leadDetails) {
        Lead lead = leadRepository.findById(id).orElse(null);
        if (lead == null) return null;

        lead.setName(leadDetails.getName());
        lead.setContactInfo(leadDetails.getContactInfo());
        lead.setSource(leadDetails.getSource());
        lead.setStatus(leadDetails.getStatus());

        if (leadDetails.getAssignedSalesRep() != null && leadDetails.getAssignedSalesRep().getId() != null) {
            User salesRep = userRepository.findById(leadDetails.getAssignedSalesRep().getId()).orElse(null);
            lead.setAssignedSalesRep(salesRep);
        }

        return leadRepository.save(lead);
    }

    public void deleteLead(Long id) {
        leadRepository.deleteById(id);
    }
}
