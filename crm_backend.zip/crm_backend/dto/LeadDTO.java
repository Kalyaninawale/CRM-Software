package com.crm.crm_backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeadDTO {
    private Long id;
    private String name;
    private String contactInfo;
    private String source;
    private String status;
    private String assignedSalesRepName; // only name instead of full user object
}
