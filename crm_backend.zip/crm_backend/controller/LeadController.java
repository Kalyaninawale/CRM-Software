package com.crm.crm_backend.controller;

import com.crm.crm_backend.dto.LeadDTO;
import com.crm.crm_backend.model.Lead;
import com.crm.crm_backend.service.LeadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leads")
@CrossOrigin(origins = "http://localhost:3000")
public class LeadController {

    @Autowired
    private LeadService leadService;

    // ✅ Create lead
    @PostMapping
    public ResponseEntity<LeadDTO> createLead(@RequestBody Lead lead) {
        Lead savedLead = leadService.createLead(lead);
        LeadDTO leadDTO = leadService.convertToDTO(savedLead);
        return ResponseEntity.ok(leadDTO);
    }

    // ✅ Get all leads
    @GetMapping
    public ResponseEntity<List<LeadDTO>> getAllLeads() {
        return ResponseEntity.ok(leadService.getAllLeads());
    }

    // ✅ Get lead by ID
    @GetMapping("/{id}")
    public ResponseEntity<LeadDTO> getLeadById(@PathVariable Long id) {
        Lead lead = leadService.getLeadById(id);
        if (lead == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(leadService.convertToDTO(lead));
    }

    // ✅ Update lead
    @PutMapping("/{id}")
    public ResponseEntity<LeadDTO> updateLead(@PathVariable Long id, @RequestBody Lead lead) {
        Lead updated = leadService.updateLead(id, lead);
        if (updated == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(leadService.convertToDTO(updated));
    }

    // ✅ Delete lead
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLead(@PathVariable Long id) {
        leadService.deleteLead(id);
        return ResponseEntity.noContent().build();
    }
}
