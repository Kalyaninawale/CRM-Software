package com.crm.crm_backend.model;

public enum Role {
	ADMIN, SALES
}
