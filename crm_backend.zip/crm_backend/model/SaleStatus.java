package com.crm.crm_backend.model;

public enum SaleStatus {
    PROPOSAL,
    NEGOTIATION,
    CLOSED_WON,
    CLOSED_LOST
}
