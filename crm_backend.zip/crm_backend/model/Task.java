package com.crm.crm_backend.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.Date;

@Entity

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tasks")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;

    @Temporal(TemporalType.DATE)
    private Date dueDate;

    private String priority;  // Low, Medium, High
    private String status;    // Open, In Progress, Completed

    @ManyToOne
    @JoinColumn(name = "assigned_to_user_id")
    private User assignedTo;
}
